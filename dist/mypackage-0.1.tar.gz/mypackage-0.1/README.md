# mypackage
This library was created as an example of ow to publish your own Python package.

## building thi package locally
`python setup.py sdist`

## installing this package from Github
`pip install git+https://github.com/tashca/mypackage.git`

## updating this package from Github
`pip install --upgrade git+https://github.com/tashca/mypackage.git`